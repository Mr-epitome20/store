<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mdb.min.css">
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body class="bg-info">
<nav class="navbar navbar-expand-lg navbar-light bg-light" style="">
	<a class="navbar-brand" href="/"><b>CRUD</b></a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSuportedContent">
		<span class="navbar-toggler-icon"></span>
	</button>

	<div class="collapse navbar-collapse" id="navbarSuportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item disabled">
				<a class="nav-link" href="/">Home<span class="sr-only">(current)</span></a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="create.php"><b>Create Person</b></a>
			</li>
		</ul>
	</div>
</nav><br/>