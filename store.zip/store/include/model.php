

<?php 
	/**
	* 
	*/
	class Model
	{
		private $server = "localhost";
		private $username = "root";
		private $password = "";
		private $db = "store";
		private $conn = "";
		
		function __construct()
		{
			try {
				$this->conn = new mysqli($this->server, $this->username, $this->password, $this->db);
			} catch (Exception $e) {
				echo "Connection Failed ". $e->getMessage();
			}
		}

		public function insert(){

			$message = "";

			if (isset($_POST) AND !empty($_POST)) {
					$target_cover = 'covers/'.basename($_FILES['image']['name']);
					move_uploaded_file($_FILES['image']['tmp_name'], $target_cover);
					$target_book = 'books/'.basename($_FILES['book']['name']);
					move_uploaded_file($_FILES['book']['tmp_name'], $target_book);

					$b_name = $_POST['bname'];
					$ath_name = $_POST['ath_name'];
					$isbn = $_POST['isbn'];
					$image = $_FILES['image']['name'];
					$book = $_FILES['book']['name'];
					$des = $_POST['des'];

					if (empty($b_name) OR empty($ath_name) OR empty($isbn) OR empty($image) OR empty($book) OR empty($des)) {
							echo "<script>alert('Please fill all Fileds');</script>";
							echo "<script>window.location.href = 'insert.php';</script>";
					}else{

						$query = "INSERT INTO books (b_name, ath_name, isbn, image, pdf, des) VALUES ('$b_name', '$ath_name', '$isbn', '$image', '$book', '$des')";
						if ($sql = $this->conn->query($query)) {
							echo "<script>alert('Record inserted successfully');</script>";
							echo "<script>window.location.href = 'insert.php';</script>";
						}else{
							echo "<script>alert('Record wasn't inserted for some reason);</script>";
							echo "<script>window.location.href = 'insert.php';</script>";
						}
					}
			}
		}

		public function index(){
			$data = null;
			$query = "SELECT * FROM books";
			if ($sql = $this->conn->query($query)) {
				while ($row = mysqli_fetch_assoc($sql)) {
					$data[] = $row;
				}
			}
			return $data;
		}

		public function delete($id){
			$query = "DELETE FROM books WHERE id ='$id'";
			if ($sql = $this->conn->query($query)) {
				return true;
			}else{
				return false;
			}
		}
	}


?>