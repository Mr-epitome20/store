<?php 
	require_once 'include/header.php';
?>
<link rel="stylesheet" type="text/css" href="css/DataTables/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="css/DataTables/css/jquery.dataTablesjqueryui.min.css">
<script type="text/javascript" src="css/DataTables/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="css/DataTables/js/jquery.dataTablesjqueryui.min.js"></script>
<script>
$(document).ready(function() {
    $('.table').DataTable( {
        columnDefs: [
            {
                targets: [ 0, 1, 2 ],
                className: 'mdl-data-table__cell--non-numeric'
            }
        ]
    } );
} );
</script>
<div class="container">
	<div class="card table-responsive">
		<table class="table dataTable">
			<thead>
				<tr>
					<th>ID</th>
					<th>Book Name</th>
					<th>Authors Name </th>
					<th>ISBN</th>
					<th>Action</th>
				</tr>
			</thead>
		<?php
			require_once 'include/model.php';
			$model = new Model();
			$rows = $model->index();
			$i = 1;

			foreach ($rows as $row) {
		?>

			<tbody>
				<tr>
					<td><?= $i++ ?></td>
					<td><?= $row['b_name'] ?></td>
					<td><?= $row['ath_name'] ?></td>
					<td><?= $row['isbn'] ?></td>
					<td>
						<a href="read.php?<?= $row['id']; ?>" class="badge badge-info">Read</a>
						<a href="delete.php?<?= $row['id']; ?>" class="badge badge-danger">Delete</a>
						<a href="edit.php?<?= $row['id']; ?>" class="badge badge-success">Edit</a>
					</td>
				</tr>
			</tbody>
<?php
}
?>
		</table>
	</div>
</div>
<?php 
	require_once 'include/footer.php';
?>