<?php 
	require_once 'include/header.php';
?>
<link rel="stylesheet" type="text/css" href="css/main.css">
<style>
.morecontent span {
    display: none;
}
.morelink {
    display: block;
}
</style>
<script>
$(document).ready(function() {
    // Configure/customize these variables.
    var showChar = 150;  // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "Read more";
    var lesstext = "Read less";
    

    $('.more').each(function() {
        var content = $(this).html();
 
        if(content.length > showChar) {
 
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
 
            var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';
 
            $(this).html(html);
        }
 
    });
 
    $(".morelink").click(function(){
        if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().fadeToggle();
        $(this).prev().fadeToggle();
        return false;
    });
});
</script>
<?php
	require_once 'include/model.php';
	$model = new Model();
	$rows = $model->index();

	foreach ($rows as $row) {
?>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-md-4 center">
						<img src="covers/<?= $row['image'] ?>" style="width: 350px; height: 460px;">
					</div>
					<div class="col-md-8 t-center"><br>
						<h3><?= $row['b_name'] ?></h3>
						<h4 class="">By: <?= $row['ath_name'] ?></h4><br>
						<p class="text-justify more"><?= $row['des'] ?></p>
				        <a href="books/<?= $row['pdf'] ?>" target="_blank"><button type="button" class="btn btn-info btn-lg" >Read Book</button></a>
				        <!-- Modal -->
				        <div id="myModal" class="modal fade" role="dialog">
				            <div class="modal-dialog modal-lg">

				                <!-- Modal content-->
<!-- 				                <div class="modal-content">
				                    <div class="modal-header">
				                        <h4 class="modal-title"><?= $row['b_name'] ?></h4>
				                        <button type="button" class="close" data-dismiss="modal">&times;</button>
				                    </div>
				                    <div class="modal-body">

				                    	<embed src="books/<?= $row['book'] ?>" frameborder="0" width="100%" height="550px"></embed>
				                        <div class="modal-footer">
				                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				                        </div>
				                    </div>

				                </div> -->
				            </div>
				        </div>
					</div>
				</div>
			</div>
		</div>
	</div><br>


<?php 
	}
	require_once 'include/footer.php';
?>