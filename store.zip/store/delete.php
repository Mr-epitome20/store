<?php 

	include_once 'home.php';
	include_once 'include/model.php';
	$model = new Model();
	$id = $_REQUEST['id'];
	$delete = $model->delete($id);

	if ($delete) {
		echo "<script>alert('Record Deleted successfully');</script>";
		echo "<script>window.location.href = 'home.php';</script>";
	}

?>