<?php 
	require_once 'include/header.php';
?>
<div class="container">
	<form>
		<div class="row">
			<div class="col-md-12 mx-auto">
				<div class="card">
						<div class="card-header">
							<h2 class="text-center">Register Admin</h2>
						</div>
						<div class="card-body">
							
						</div>
				</div>
			</div>
		</div>
	</form>
</div>

<?php 
	require_once 'include/footer.php';
?>