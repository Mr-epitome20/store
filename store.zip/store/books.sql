CREATE DATABASE `store`;

use books;

CREATE TABLE `books` (

	id int(11) not null AUTO_INCREMENT PRIMARY KEY,
	b_name varchar(255) not null,
	ath_name varchar(255) not null,
	isbn varchar(255) not null,
	image varchar(255) not null,
	book varchar(255) not null,
	des text() not null

);