<?php 
	require_once 'include/header.php';
?>
<link rel="stylesheet" type="text/css" href="css/main.css">
<div class="container">
	<form method="post" enctype="multipart/form-data">
		<?php 
			require_once 'include/model.php';
			$model = new Model();
			$model->insert();
		?>
		<div class="row">
			<div class="col-md-12 mx-auto">
				<div class="card">
						<div class="card-header">
							<h2 class="text-center">Insert A Book</h2>
						</div>
						<div class="card-body">
							<div class="form-group">
								<label for="bname">Book Name:</label>
								<input type="text" name="bname" class="form-control">
							</div>
							<div class="form-group">
								<label for="athname">Authors Name:</label>
								<input type="text" name="ath_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="isbn">ISBN:</label>
								<input type="text" name="isbn" class="form-control">
							</div>
							<div class="form-group">
								<label for="image">Upload Book Cover:</label><br>
								<input type="file" name="image" class="btn btn-success">
							</div>
							<div class="form-group">
								<label for="book">Upload Book:</label><br>
								<input type="file" name="book" class="btn btn-success" accept="appliction/pdf">
							</div>
							<div class="form-group">
								<label for="des">Description:</label>
								<textarea name="des" class="form-control"></textarea>
							</div>
							<div class="form-group">
								<button class="btn btn-info">Upload Book</button>
							</div>
						</div>
				</div>
			</div>
		</div>
	</form>
</div>

<?php 
	require_once 'include/footer.php';
?>